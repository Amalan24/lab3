let product = document.getElementById("name");
let price = document.getElementById("price");
let des = document.getElementById("description");
let image = document.getElementById("imageUpload");
let add = document.getElementById("add");
let dis = document.getElementById("display");

var names = [];
var cost = [];
var images = [];



image.addEventListener('change',function(){
    const file = imageUpload.files[0];

    if(file){
        var reader = new FileReader();
        reader.onload = function(){
            previewImage.src = reader.result;
            images.push(reader.result);
            console.log(images)
            previewImage.style.display = 'block';
        }

        reader.readAsDataURL(file);
    }
});

add.addEventListener('click',()=>{
    if(product.value || price.value){
        display.innerHTML = "";
        names.push(product.value);
        cost.push(price.value);
        for(let i=0;i<images.length;i++){
        var imageElement = document.createElement('img');
        var name = document.createElement('p');
        name.setAttribute("id","name1");
        var amt = document.createElement('p');
        amt.setAttribute("id","amount");
        imageElement.src = images[i];
        name.textContent = names[i];
        amt.textContent = " ---- ₹ "+cost[i];
        dis.appendChild(imageElement);
        dis.appendChild(name);
        dis.appendChild(amt);
        }
    }
    product.value='';
    price.value='';
    des.value='';
    previewImage.style.display="none";
});


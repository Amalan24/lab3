let completed = document.querySelectorAll(".completed");
let ongoing = document.querySelectorAll(".ongoing");
let upcoming = document.querySelectorAll(".upcoming");
let year = document.getElementById("year");
let date = document.getElementsByClassName('date');

var colors = ["red","blue","orange","purple","yellow"];
var index = 0

function colorChange(){
    year.style.color = colors[index];
    index++;
    if(index>=colors.length){index=0}
}

setInterval(colorChange,3000)

var color=["blue","pink","orange","violet","white"]

function changeColor(){
    for(let i=0;i<date.length;i++){
        date[i].style.backgroundColor=color[index];
    }
    index++;
    if(index>=colors.length){index=0}
}

setInterval(changeColor,1000)

for(let i=0;i<completed.length;i++){
    completed[i].style.backgroundColor = "green";
}

for(let i=0;i<ongoing.length;i++){
    ongoing[i].style.backgroundColor = "yellow";
}

for(let i=0;i<upcoming.length;i++){
    upcoming[i].style.backgroundColor = "red";
}
